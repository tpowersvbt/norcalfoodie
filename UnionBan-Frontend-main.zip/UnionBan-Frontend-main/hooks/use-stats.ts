"use client"

import { useEffect, useState } from "react"
import { statsStore } from "@/lib/stats-store"
import { unionBanAPI } from "@/lib/api"

interface StatsData {
  totalBans: number
  pendingReviews: number
  activeBans: number
  lastUpdated: number
}

export function useStats() {
  const [stats, setStats] = useState<StatsData | null>(statsStore.getStats())
  const [loading, setLoading] = useState(statsStore.isLoading())
  const [error, setError] = useState<string>("")
  const [isLoggedIn, setIsLoggedIn] = useState(false)

  useEffect(() => {
    const checkLoginStatus = () => {
      const loggedIn = unionBanAPI.isLoggedIn()
      setIsLoggedIn(loggedIn)

      // 如果用户登出，清除统计数据和错误
      if (!loggedIn) {
        statsStore.clearCache()
        setError("")
      }
    }

    checkLoginStatus()

    // 定期检查登录状态
    const interval = setInterval(checkLoginStatus, 5000)
    return () => clearInterval(interval)
  }, [])

  useEffect(() => {
    const unsubscribe = statsStore.subscribe(() => {
      setStats(statsStore.getStats())
      setLoading(statsStore.isLoading())
    })

    if (isLoggedIn && !statsStore.getStats() && !statsStore.isLoading()) {
      loadStats()
    }

    return unsubscribe
  }, [isLoggedIn])

  const loadStats = async (force = false) => {
    if (!isLoggedIn) {
      setError("请先登录")
      return
    }

    try {
      setError("")
      await statsStore.loadStats(force)
    } catch (err) {
      let errorMessage = err instanceof Error ? err.message : "加载统计数据失败"

      if (errorMessage.includes("Token已过期") || errorMessage.includes("认证失效")) {
        errorMessage = "登录已过期，请重新登录"
        // 触发登录状态检查
        setIsLoggedIn(false)
      }

      setError(errorMessage)
    }
  }

  const refreshStats = () => loadStats(true)

  return {
    stats,
    loading,
    error,
    isLoggedIn,
    loadStats,
    refreshStats,
  }
}
