import { unionBanAPI } from "./api"

interface StatsData {
  totalBans: number
  pendingReviews: number
  activeBans: number
  lastUpdated: number
}

class StatsStore {
  private data: StatsData | null = null
  private loading = false
  private listeners: Set<() => void> = new Set()
  private readonly CACHE_DURATION = 30000 // 30秒缓存

  subscribe(listener: () => void) {
    this.listeners.add(listener)
    return () => this.listeners.delete(listener)
  }

  private notify() {
    this.listeners.forEach((listener) => listener())
  }

  getStats(): StatsData | null {
    return this.data
  }

  isLoading(): boolean {
    return this.loading
  }

  isCacheValid(): boolean {
    if (!this.data) return false
    return Date.now() - this.data.lastUpdated < this.CACHE_DURATION
  }

  async loadStats(force = false): Promise<StatsData> {
    if (!unionBanAPI.isLoggedIn()) {
      throw new Error("用户未登录")
    }

    if (!force && this.isCacheValid() && this.data) {
      return this.data
    }

    if (this.loading) {
      return new Promise((resolve, reject) => {
        const checkLoading = () => {
          if (!this.loading) {
            if (this.data) {
              resolve(this.data)
            } else {
              reject(new Error("Failed to load stats"))
            }
          } else {
            setTimeout(checkLoading, 100)
          }
        }
        checkLoading()
      })
    }

    try {
      this.loading = true
      this.notify()

      console.log("[v0] StatsStore: 开始加载统计数据")

      const [allBansResponse, pendingBansResponse] = await Promise.all([
        unionBanAPI.getBans(),
        unionBanAPI.getBansNoVerify(),
      ])

      const totalBans = allBansResponse?.data?.bans ? allBansResponse.data.bans.length : 0
      const pendingReviews = pendingBansResponse?.data?.bans ? pendingBansResponse.data.bans.length : 0
      const activeBans = totalBans - pendingReviews

      this.data = {
        totalBans,
        pendingReviews,
        activeBans,
        lastUpdated: Date.now(),
      }

      console.log("[v0] StatsStore: 统计数据加载完成", this.data)

      this.notify()
      return this.data
    } catch (error) {
      console.error("[v0] StatsStore: 加载统计数据失败", error)

      if (error instanceof Error && (error.message.includes("Token已过期") || error.message.includes("认证失效"))) {
        this.clearCache()
      }

      throw error
    } finally {
      this.loading = false
      this.notify()
    }
  }

  clearCache() {
    this.data = null
    this.notify()
  }
}

export const statsStore = new StatsStore()
