const API_BASE_URL = "http://localhost:5000"

export interface BanUser {
  username: string
  reason: string
  server: string
  created_by: string
  expires_at: string | null
  is_permanent: string
}

export interface UnbanUser {
  username: string
}

export interface CheckBanned {
  username: string
}

export interface ReviewBan {
  ban_id: string
}

export interface ApiResponse<T = any> {
  code: number
  message: string
  data: T
}

export interface BanStatusResponse {
  result: boolean
  id?: number
  username?: string
  reason?: string
  server?: string
  created_by?: string
  created_at?: string
  expires_at?: string | null
  is_permanent?: boolean
  reviewed?: boolean
}

export interface PendingBan {
  id: number // 修改为number类型匹配API响应
  username: string
  reason: string
  server: string
  created_by: string
  expires_at: string | null
  is_permanent: boolean
  created_at: string
  reviewed: boolean // 添加reviewed字段
}

export interface BansResponse {
  bans: PendingBan[]
}

export interface LoginResponse {
  access_token: string
  token_type: string
  expires_in: number
}

export interface TokenInfo {
  token: string
  expiresAt: number
}

export class UnionBanAPI {
  private async makeRequest<T = any>(
    endpoint: string,
    options: RequestInit = {},
    requireAuth = true,
  ): Promise<ApiResponse<T>> {
    try {
      console.log("[v0] Making API request to:", `${API_BASE_URL}${endpoint} with data ${options.body}`)

      let body = options.body

      if (endpoint !== "/login" && requireAuth) {
        const token = await this.getValidToken()

        if (options.method === "POST" && body) {
          const bodyData = JSON.parse(body as string)
          delete bodyData.password // 删除password字段
          bodyData.token = token // 添加token字段
          body = JSON.stringify(bodyData)
        } else {
          body = JSON.stringify({ token })
        }
      } else if (endpoint !== "/login" && endpoint !== "/check_banned" && !requireAuth) {
        throw new Error("此功能需要用户提供密码")
      }

      const headers: Record<string, string> = {
        "Content-Type": "application/json",
        ...options.headers,
      }

      const response = await fetch(`${API_BASE_URL}${endpoint}`, {
        ...options,
        headers,
        body,
        mode: "cors",
      })


      if (!response.ok) {
        const errorText = await response.text()
        let errorMessage = `API请求失败: ${response.status} ${response.statusText}`

        try {
          const errorJson = JSON.parse(errorText)
          errorMessage = errorJson.message || errorMessage
        } catch {
          // Use default error message if JSON parsing fails
        }

        // 如果是401错误，清除token
        if (response.status === 401) {
          this.clearStoredToken()
          errorMessage = "认证失效，请重新登录"
        }

        throw new Error(errorMessage)
      }

      const data = await response.json()
      return data
    } catch (error) { 
      if (error instanceof Error) {
        if (error.message.includes("Failed to fetch")) {
          throw new Error(
            `无法连接到API服务器 (${API_BASE_URL})。请检查：\n1. API服务器是否正在运行\n2. API地址是否正确\n3. CORS是否正确配置`,
          )
        }
        throw error
      }
      throw new Error("网络错误")
    }
  }

  private getStoredToken(): TokenInfo | null {
    if (typeof window === "undefined") return null

    const tokenData = localStorage.getItem("unionban_token")
    if (!tokenData) return null

    try {
      return JSON.parse(tokenData)
    } catch {
      return null
    }
  }

  private setStoredToken(token: string, expiresIn: number): void {
    if (typeof window === "undefined") return

    const tokenInfo: TokenInfo = {
      token,
      expiresAt: Date.now() + expiresIn * 1000,
    }
    localStorage.setItem("unionban_token", JSON.stringify(tokenInfo))
  }

  private clearStoredToken(): void {
    if (typeof window === "undefined") return
    localStorage.removeItem("unionban_token")
  }

  private isTokenValid(tokenInfo: TokenInfo): boolean {
    return Date.now() < tokenInfo.expiresAt - 5000 // 提前5秒刷新
  }

  private async getValidToken(): Promise<string> {
    const tokenInfo = this.getStoredToken()

    if (tokenInfo && this.isTokenValid(tokenInfo)) {
      return tokenInfo.token
    }

    try {
      await this.refreshToken()
      const newTokenInfo = this.getStoredToken()
      if (newTokenInfo && this.isTokenValid(newTokenInfo)) {
        return newTokenInfo.token
      }
    } catch (error) {
    }

    // Token过期或不存在，需要重新登录
    throw new Error("Token已过期，请重新登录")
  }

  private async refreshToken(): Promise<void> {
    const tokenInfo = this.getStoredToken()
    if (!tokenInfo) {
      throw new Error("No token to refresh")
    }

    // 如果token还有超过30分钟有效期，不需要刷新
    if (Date.now() < tokenInfo.expiresAt - 30 * 60 * 1000) {
      return
    }
    throw new Error("Token refresh not supported, please login again")
  }

  async login(password: string): Promise<ApiResponse<LoginResponse>> {
    const response = await this.makeRequest<LoginResponse>(
      "/login",
      {
        method: "POST",
        body: JSON.stringify({
          password: password,
        }),
      },
      false,
    )

    // 存储token
    if (response.data) {
      this.setStoredToken(response.data.access_token, 3600) // 1小时 = 3600秒
    }

    return response
  }

  logout(): void {
    this.clearStoredToken()
  }

  isLoggedIn(): boolean {
    const tokenInfo = this.getStoredToken()
    return tokenInfo !== null && this.isTokenValid(tokenInfo)
  }

  async ping(): Promise<ApiResponse> {
    return this.makeRequest("/", {
      method: "POST",
    })
  }

  async banUser(data: BanUser): Promise<ApiResponse> {
    return this.makeRequest("/ban_user", {
      method: "POST",
      body: JSON.stringify(data),
    }, true)
  }

  async unbanUser(data: UnbanUser): Promise<ApiResponse> {
    return this.makeRequest("/unban_user", {
      method: "POST",
      body: JSON.stringify(data),
    }, true)
  }

  async checkBanned(data: CheckBanned): Promise<ApiResponse<BanStatusResponse>> {
    return this.makeRequest<BanStatusResponse>(
      "/check_banned",
      {
        method: "POST",
        body: JSON.stringify(data),
      },
      false,
    )
  }

  async getBansNoVerify(): Promise<ApiResponse<BansResponse>> {
    return this.makeRequest<BansResponse>(
      "/get_bans_noverify",
      {
        method: "POST",
      },
      true,
    )
  }

  async getBans(): Promise<ApiResponse<BansResponse>> {
    return this.makeRequest<BansResponse>(
      "/get_bans",
      {
        method: "POST",
      },
      true,
    )
  }

  async reviewBan(data: ReviewBan): Promise<ApiResponse> {
    return this.makeRequest("/review_ban", {
      method: "POST",
      body: JSON.stringify({
        ban_id: data.ban_id,
      }),
    }, true)
  }

  async healthCheck(): Promise<boolean> {
    try {
      await this.ping()
      return true
    } catch {
      return false
    }
  }
}

export const checkAPIConnection = async (): Promise<{ connected: boolean; error?: string }> => {
  try {
    await unionBanAPI.ping()
    return { connected: true }
  } catch (error) {
    return {
      connected: false,
      error: error instanceof Error ? error.message : "未知错误",
    }
  }
}

export const unionBanAPI = new UnionBanAPI()
