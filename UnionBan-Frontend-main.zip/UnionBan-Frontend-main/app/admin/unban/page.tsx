import { UnbanUserForm } from "@/components/unban-user-form"

export default function UnbanUserPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">Unban User</h1>
        <p className="text-muted-foreground">Remove an existing ban for a user</p>
      </div>
      <UnbanUserForm />
    </div>
  )
}
