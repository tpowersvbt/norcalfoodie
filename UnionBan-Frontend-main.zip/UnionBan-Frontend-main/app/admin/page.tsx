import { AdminDashboard } from "@/components/admin-dashboard"
import { AuthWrapper } from "@/components/auth-wrapper"

export default function AdminPage() {
  return (
    <AuthWrapper requireAuth={true}>
      <AdminDashboard />
    </AuthWrapper>
  )
}
