import { ReviewBansInterface } from "@/components/review-bans-interface"

export default function ReviewBansPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">审核封禁</h1>
        <p className="text-muted-foreground">审核和批准待处理的封禁请求</p>
      </div>
      <ReviewBansInterface />
    </div>
  )
}
