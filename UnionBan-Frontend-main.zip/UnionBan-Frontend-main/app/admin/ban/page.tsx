import { BanUserForm } from "@/components/ban-user-form"
import { AuthWrapper } from "@/components/auth-wrapper"

export default function BanUserPage() {
  return (
    <AuthWrapper requireAuth={true}>
      <div className="space-y-6">
        <div>
          <h1 className="text-3xl font-bold text-foreground">封禁用户</h1>
          <p className="text-muted-foreground">对用户进行跨服务器封禁</p>
        </div>
        <BanUserForm />
      </div>
    </AuthWrapper>
  )
}
