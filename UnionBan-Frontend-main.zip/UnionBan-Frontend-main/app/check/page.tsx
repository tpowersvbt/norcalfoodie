import { CheckUserStatus } from "@/components/check-user-status"

export default function CheckUserPage() {
  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-3xl font-bold text-foreground">检查用户状态</h1>
        <p className="text-muted-foreground">查询用户是否被封禁及详细信息</p>
      </div>
      <CheckUserStatus />
    </div>
  )
}
