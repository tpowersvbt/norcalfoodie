import { NextResponse } from "next/server"
import { unionBanAPI } from "@/lib/api"

export async function GET() {
  try {
    const isHealthy = await unionBanAPI.healthCheck()

    return NextResponse.json({
      status: isHealthy ? "healthy" : "unhealthy",
      timestamp: new Date().toISOString(),
      api_connected: isHealthy,
    })
  } catch (error) {
    return NextResponse.json(
      {
        status: "error",
        timestamp: new Date().toISOString(),
        api_connected: false,
        error: error instanceof Error ? error.message : "Unknown error",
      },
      { status: 500 },
    )
  }
}
