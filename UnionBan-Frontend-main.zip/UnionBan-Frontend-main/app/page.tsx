"use client"
import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Shield, Users, Eye, Settings, RefreshCw } from "lucide-react"
import { AuthWrapper } from "@/components/auth-wrapper"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { useStats } from "@/hooks/use-stats"

interface HomeStats {
  totalBans: number
  pendingReviews: number
  activeBans: number
}

export default function HomePage() {
  const { stats, loading, error, isLoggedIn } = useStats()

  return (
    <AuthWrapper requireAuth={false}>
      <div className="min-h-screen bg-background">
        {/* Header */}
        <header className="border-b border-border bg-card">
          <div className="container mx-auto px-4 py-6">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Shield className="h-8 w-8 text-accent" />
                <div>
                  <h1 className="text-2xl font-bold text-foreground">UnionBan</h1>
                  <p className="text-sm text-muted-foreground">用户封禁管理系统</p>
                </div>
              </div>
              <div className="flex space-x-3">
                <Button asChild variant="outline">
                  <Link href="/check">检查用户状态</Link>
                </Button>
                {isLoggedIn ? (
                  <Button asChild>
                    <Link href="/admin">管理面板</Link>
                  </Button>
                ) : (
                  <Button asChild>
                    <Link href="/login">管理员登录</Link>
                  </Button>
                )}
              </div>
            </div>
          </div>
        </header>

        {/* Main Content */}
        <main className="container mx-auto px-4 py-12">
          <div className="text-center mb-12">
            <h2 className="text-4xl font-bold text-foreground mb-4">专业的用户封禁管理解决方案</h2>
            <p className="text-xl text-muted-foreground max-w-2xl mx-auto">
              UnionBan 提供完整的用户封禁管理功能，支持多服务器统一管理，审核流程和状态查询。
            </p>
          </div>

          {isLoggedIn && (
            <div className="grid md:grid-cols-3 gap-6 mb-12">
              <Card>
                <CardHeader className="text-center">
                  <CardTitle className="text-2xl font-bold text-primary">
                    {loading ? <RefreshCw className="h-6 w-6 animate-spin mx-auto" /> : stats?.totalBans || 0}
                  </CardTitle>
                  <CardDescription>总封禁数量</CardDescription>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader className="text-center">
                  <CardTitle className="text-2xl font-bold text-orange-500">
                    {loading ? <RefreshCw className="h-6 w-6 animate-spin mx-auto" /> : stats?.pendingReviews || 0}
                  </CardTitle>
                  <CardDescription>待审核封禁</CardDescription>
                </CardHeader>
              </Card>
              <Card>
                <CardHeader className="text-center">
                  <CardTitle className="text-2xl font-bold text-destructive">
                    {loading ? <RefreshCw className="h-6 w-6 animate-spin mx-auto" /> : stats?.activeBans || 0}
                  </CardTitle>
                  <CardDescription>活跃封禁</CardDescription>
                </CardHeader>
              </Card>
            </div>
          )}

          {!isLoggedIn && (
            <div className="mb-12">
              <Alert>
                <AlertDescription className="text-center">请先登录以查看统计数据</AlertDescription>
              </Alert>
            </div>
          )}

          {error && (
            <div className="mb-12">
              <Alert>
                <AlertDescription className="text-center text-destructive">{error}</AlertDescription>
              </Alert>
            </div>
          )}

          {/* Feature Cards */}
          <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 mb-12">
            <Card>
              <CardHeader>
                <Users className="h-8 w-8 text-accent mb-2" />
                <CardTitle>用户管理</CardTitle>
                <CardDescription>统一管理多个服务器的用户封禁状态</CardDescription>
              </CardHeader>
              <CardContent>
                <Button asChild variant="outline" className="w-full bg-transparent">
                  <Link href="/admin/ban">封禁用户</Link>
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Eye className="h-8 w-8 text-accent mb-2" />
                <CardTitle>状态查询</CardTitle>
                <CardDescription>快速查询用户的封禁状态和详细信息</CardDescription>
              </CardHeader>
              <CardContent>
                <Button asChild variant="outline" className="w-full bg-transparent">
                  <Link href="/check">查询状态</Link>
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Settings className="h-8 w-8 text-accent mb-2" />
                <CardTitle>审核管理</CardTitle>
                <CardDescription>审核待处理的封禁申请和管理流程</CardDescription>
              </CardHeader>
              <CardContent>
                <Button asChild variant="outline" className="w-full bg-transparent">
                  <Link href={isLoggedIn ? "/admin/review" : "/login"}>{isLoggedIn ? "审核封禁" : "需要登录"}</Link>
                </Button>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <Shield className="h-8 w-8 text-accent mb-2" />
                <CardTitle>解封管理</CardTitle>
                <CardDescription>管理用户解封申请和处理流程</CardDescription>
              </CardHeader>
              <CardContent>
                <Button asChild variant="outline" className="w-full bg-transparent">
                  <Link href="/admin/unban">解封用户</Link>
                </Button>
              </CardContent>
            </Card>
          </div>

          {/* Quick Access */}
          <div className="text-center">
            <Card className="max-w-md mx-auto">
              <CardHeader>
                <CardTitle>快速访问</CardTitle>
                <CardDescription>选择您需要的功能</CardDescription>
              </CardHeader>
              <CardContent className="space-y-3">
                <Button asChild className="w-full" size="lg">
                  <Link href="/check">检查用户封禁状态</Link>
                </Button>
                <Button asChild variant="outline" className="w-full bg-transparent" size="lg">
                  <Link href={isLoggedIn ? "/admin" : "/login"}>{isLoggedIn ? "管理面板" : "管理员功能"}</Link>
                </Button>
              </CardContent>
            </Card>
          </div>
        </main>

        {/* Footer */}
        <footer className="border-t border-border bg-card mt-16">
          <div className="container mx-auto px-4 py-8">
            <div className="text-center text-muted-foreground">
              <p>&copy; 2025 UnionBan 用户封禁管理系统</p>
            </div>
          </div>
        </footer>
      </div>
    </AuthWrapper>
  )
}
