import { NextResponse } from "next/server"
import type { NextRequest } from "next/server"

export function middleware(request: NextRequest) {
  if (request.nextUrl.pathname.startsWith("/admin")) {
    // Check for token in localStorage (client-side check will be handled by components)
    // Server-side middleware just ensures the route structure is correct
    return NextResponse.next()
  }

  return NextResponse.next()
}

export const config = {
  matcher: ["/admin/:path*"], // 扩展到所有admin路由
}
