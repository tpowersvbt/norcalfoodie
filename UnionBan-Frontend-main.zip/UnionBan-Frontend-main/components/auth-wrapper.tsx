"use client"

import type React from "react"

import { useEffect, useState } from "react"
import { useRouter, usePathname } from "next/navigation"
import { unionBanAPI } from "@/lib/api"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { RefreshCw } from "lucide-react"

interface AuthWrapperProps {
  children: React.ReactNode
  requireAuth?: boolean
}

export function AuthWrapper({ children, requireAuth = false }: AuthWrapperProps) {
  const [isAuthenticated, setIsAuthenticated] = useState<boolean | null>(null)
  const [error, setError] = useState<string>("")
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    const checkAuth = () => {
      if (!requireAuth) {
        setIsAuthenticated(true)
        return
      }

      const isLoggedIn = unionBanAPI.isLoggedIn()
      setIsAuthenticated(isLoggedIn)

      if (!isLoggedIn && pathname.startsWith("/admin")) {
        router.push("/login")
      }
    }

    checkAuth()
  }, [requireAuth, pathname, router])

  const handleRetry = () => {
    setError("")
    const isLoggedIn = unionBanAPI.isLoggedIn()
    setIsAuthenticated(isLoggedIn)

    if (!isLoggedIn && requireAuth) {
      router.push("/login")
    }
  }

  if (isAuthenticated === null) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <div className="text-center">
          <RefreshCw className="h-8 w-8 animate-spin mx-auto mb-4" />
          <p className="text-muted-foreground">检查认证状态...</p>
        </div>
      </div>
    )
  }

  if (requireAuth && !isAuthenticated) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center p-4">
        <div className="max-w-md w-full">
          <Alert>
            <AlertDescription>您需要登录才能访问此页面。</AlertDescription>
          </Alert>
          <div className="mt-4 space-x-2">
            <Button onClick={() => router.push("/login")}>前往登录</Button>
            <Button variant="outline" onClick={handleRetry}>
              重试
            </Button>
          </div>
        </div>
      </div>
    )
  }

  return <>{children}</>
}
