"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Search, AlertTriangle, CheckCircle, UserCheck, UserX } from "lucide-react"
import { unionBanAPI, type BanStatusResponse } from "@/lib/api"

export function CheckUserStatus() {
  const [username, setUsername] = useState("")
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState("")
  const [banStatus, setBanStatus] = useState<BanStatusResponse | null>(null)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")
    setBanStatus(null)

    try {
      const response = await unionBanAPI.checkBanned({ username })
      setBanStatus(response.data)
    } catch (err) {
      setError(err instanceof Error ? err.message : "检查用户状态失败")
    } finally {
      setLoading(false)
    }
  }

  const formatDate = (dateString: string) => {
    try {
      return new Date(dateString).toLocaleString("zh-CN")
    } catch {
      return dateString
    }
  }

  return (
    <div className="space-y-6">
      <Card className="max-w-md">
        <CardHeader>
          <CardTitle className="flex items-center gap-2">
            <Search className="h-5 w-5 text-primary" />
            检查用户状态
          </CardTitle>
          <CardDescription>输入用户名以检查封禁状态</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="username">用户名 *</Label>
              <Input
                id="username"
                value={username}
                onChange={(e) => setUsername(e.target.value)}
                placeholder="输入要检查的用户名"
                required
              />
            </div>

            {error && (
              <Alert variant="destructive">
                <AlertTriangle className="h-4 w-4" />
                <AlertDescription>{error}</AlertDescription>
              </Alert>
            )}

            <Button type="submit" disabled={loading || !username.trim()} className="w-full">
              {loading ? "检查中..." : "检查状态"}
            </Button>
          </form>
        </CardContent>
      </Card>

      {banStatus && (
        <Card className="max-w-2xl">
          <CardHeader>
            <CardTitle className="flex items-center gap-2">
              {banStatus.result ? (
                <UserX className="h-5 w-5 text-destructive" />
              ) : (
                <UserCheck className="h-5 w-5 text-chart-4" />
              )}
              用户 "{username}" 的状态
            </CardTitle>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex items-center gap-2">
              <span className="font-medium">状态:</span>
              {banStatus.result ? (
                <Badge variant="destructive">已封禁</Badge>
              ) : (
                <Badge className="bg-chart-4 text-white">未封禁</Badge>
              )}
            </div>

            {banStatus.result && (
              <div className="space-y-3 p-4 bg-muted/50 rounded-lg">
                <h4 className="font-semibold text-foreground">封禁详情</h4>

                {banStatus.reason && (
                  <div>
                    <span className="font-medium text-sm">封禁原因:</span>
                    <p className="text-sm text-muted-foreground mt-1">{banStatus.reason}</p>
                  </div>
                )}

                <div className="grid grid-cols-1 md:grid-cols-2 gap-3 text-sm">
                  {banStatus.id && (
                    <div>
                      <span className="font-medium">封禁ID:</span>
                      <span className="ml-2 text-muted-foreground">{banStatus.id}</span>
                    </div>
                  )}

                  {banStatus.server && (
                    <div>
                      <span className="font-medium">服务器:</span>
                      <span className="ml-2 text-muted-foreground">{banStatus.server}</span>
                    </div>
                  )}

                  {banStatus.created_by && (
                    <div>
                      <span className="font-medium">封禁执行者:</span>
                      <span className="ml-2 text-muted-foreground">{banStatus.created_by}</span>
                    </div>
                  )}

                  {banStatus.created_at && (
                    <div>
                      <span className="font-medium">封禁时间:</span>
                      <span className="ml-2 text-muted-foreground">{formatDate(banStatus.created_at)}</span>
                    </div>
                  )}

                  {banStatus.is_permanent !== undefined && (
                    <div>
                      <span className="font-medium">封禁类型:</span>
                      <span className="ml-2 text-muted-foreground">
                        {banStatus.is_permanent ? "永久封禁" : "临时封禁"}
                      </span>
                    </div>
                  )}

                  {banStatus.expires_at && !banStatus.is_permanent && (
                    <div>
                      <span className="font-medium">到期时间:</span>
                      <span className="ml-2 text-muted-foreground">{formatDate(banStatus.expires_at)}</span>
                    </div>
                  )}

                  {banStatus.reviewed !== undefined && (
                    <div>
                      <span className="font-medium">审核状态:</span>
                      <span className="ml-2 text-muted-foreground">{banStatus.reviewed ? "已审核" : "待审核"}</span>
                    </div>
                  )}
                </div>
              </div>
            )}

            {!banStatus.result && (
              <Alert className="border-chart-4 text-chart-4">
                <CheckCircle className="h-4 w-4" />
                <AlertDescription>该用户目前未被封禁，可以正常访问所有服务器。</AlertDescription>
              </Alert>
            )}
          </CardContent>
        </Card>
      )}
    </div>
  )
}
