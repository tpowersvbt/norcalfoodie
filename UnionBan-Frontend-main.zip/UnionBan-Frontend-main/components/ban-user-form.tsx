"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Checkbox } from "@/components/ui/checkbox"
import { UserX, AlertTriangle, CheckCircle } from "lucide-react"
import { unionBanAPI } from "@/lib/api"

export function BanUserForm() {
  const [formData, setFormData] = useState({
    username: "",
    reason: "",
    server: "",
    created_by: "",
    expires_at: "",
    is_permanent: "false",
  })
  const [loading, setLoading] = useState(false)
  const [success, setSuccess] = useState("")
  const [error, setError] = useState("")

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setLoading(true)
    setError("")
    setSuccess("")

    try {
      const submitData = {
        ...formData,
        expires_at: formData.is_permanent === "true" ? null : formData.expires_at || null,
      }

      const response = await unionBanAPI.banUser(submitData)
      setSuccess(response.message || "User banned successfully!")

      // Reset form
      setFormData({
        username: "",
        reason: "",
        server: "",
        created_by: "",
        expires_at: "",
        is_permanent: "false",
      })
    } catch (err) {
      setError(err instanceof Error ? err.message : "封禁用户失败")
    } finally {
      setLoading(false)
    }
  }

  const handleInputChange = (field: string, value: string) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  return (
    <Card className="max-w-2xl">
      <CardHeader>
        <CardTitle className="flex items-center gap-2">
          <UserX className="h-5 w-5 text-destructive" />
          Ban User
        </CardTitle>
        <CardDescription>Fill out the form below to issue a ban for a user</CardDescription>
      </CardHeader>
      <CardContent>
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label htmlFor="username">Username *</Label>
              <Input
                id="username"
                value={formData.username}
                onChange={(e) => handleInputChange("username", e.target.value)}
                placeholder="Enter username"
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="server">Server *</Label>
              <Input
                id="server"
                value={formData.server}
                onChange={(e) => handleInputChange("server", e.target.value)}
                placeholder="Server name or ID"
                required
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label htmlFor="created_by">Created By *</Label>
            <Input
              id="created_by"
              value={formData.created_by}
              onChange={(e) => handleInputChange("created_by", e.target.value)}
              placeholder="Administrator username"
              required
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="reason">Reason *</Label>
            <Textarea
              id="reason"
              value={formData.reason}
              onChange={(e) => handleInputChange("reason", e.target.value)}
              placeholder="Detailed reason for the ban"
              rows={4}
              required
            />
          </div>

          <div className="space-y-4">
            <div className="flex items-center space-x-2">
              <Checkbox
                id="is_permanent"
                checked={formData.is_permanent === "true"}
                onCheckedChange={(checked) => handleInputChange("is_permanent", checked ? "true" : "false")}
              />
              <Label htmlFor="is_permanent" className="text-sm font-medium">
                Permanent Ban
              </Label>
            </div>

            {formData.is_permanent === "false" && (
              <div className="space-y-2">
                <Label htmlFor="expires_at">Expiration Date</Label>
                <Input
                  id="expires_at"
                  type="datetime-local"
                  value={formData.expires_at}
                  onChange={(e) => handleInputChange("expires_at", e.target.value)}
                  placeholder="Select expiration date and time"
                />
                <p className="text-xs text-muted-foreground">Leave empty for indefinite ban (until manually removed)</p>
              </div>
            )}
          </div>

          {error && (
            <Alert variant="destructive">
              <AlertTriangle className="h-4 w-4" />
              <AlertDescription>{error}</AlertDescription>
            </Alert>
          )}

          {success && (
            <Alert className="border-chart-4 text-chart-4">
              <CheckCircle className="h-4 w-4" />
              <AlertDescription>{success}</AlertDescription>
            </Alert>
          )}

          <Button type="submit" disabled={loading} className="w-full">
            {loading ? "Processing..." : "Ban User"}
          </Button>
        </form>
      </CardContent>
    </Card>
  )
}
