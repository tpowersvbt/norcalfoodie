"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Users, UserX, Clock, AlertTriangle, RefreshCw, Wifi, WifiOff } from "lucide-react"
import { checkAPIConnection } from "@/lib/api"
import { useStats } from "@/hooks/use-stats"

export function AdminDashboard() {
  const { stats, loading, error, isLoggedIn, refreshStats } = useStats()
  const [apiConnected, setApiConnected] = useState<boolean | null>(null)

  const checkConnection = async () => {
    const result = await checkAPIConnection()
    setApiConnected(result.connected)
    return result.connected
  }

  useEffect(() => {
    checkConnection()
  }, [])

  const handleRefresh = async () => {
    await checkConnection()
    if (isLoggedIn) {
      refreshStats()
    }
  }

  if (!isLoggedIn) {
    return (
      <div className="flex items-center justify-center h-64">
        <Card>
          <CardContent className="pt-6">
            <div className="text-center">
              <AlertTriangle className="h-8 w-8 text-orange-500 mx-auto mb-2" />
              <p className="text-muted-foreground">请先登录以查看仪表板</p>
            </div>
          </CardContent>
        </Card>
      </div>
    )
  }

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">仪表板概览</h1>
          <p className="text-muted-foreground">监控和管理服务器用户封禁</p>
        </div>
        <div className="flex items-center gap-2">
          <div className="flex items-center gap-2 text-sm">
            {apiConnected === true ? (
              <>
                <Wifi className="h-4 w-4 text-green-500" />
                <span className="text-green-500">API已连接</span>
              </>
            ) : apiConnected === false ? (
              <>
                <WifiOff className="h-4 w-4 text-red-500" />
                <span className="text-red-500">API未连接</span>
              </>
            ) : (
              <>
                <RefreshCw className="h-4 w-4 animate-spin" />
                <span>检查连接中...</span>
              </>
            )}
          </div>
          <Button onClick={handleRefresh} variant="outline" size="sm" disabled={loading}>
            <RefreshCw className={`h-4 w-4 mr-2 ${loading ? "animate-spin" : ""}`} />
            刷新
          </Button>
        </div>
      </div>

      {error && (
        <Card className="border-destructive">
          <CardContent className="pt-6">
            <div className="flex items-start gap-2 text-destructive">
              <AlertTriangle className="h-5 w-5 mt-0.5 flex-shrink-0" />
              <div className="space-y-2">
                <div className="font-medium">错误</div>
                <div className="text-sm whitespace-pre-line">{error}</div>
                {error.includes("登录已过期") && (
                  <div className="text-sm text-muted-foreground">请点击右上角的登录按钮重新登录</div>
                )}
              </div>
            </div>
          </CardContent>
        </Card>
      )}

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">总封禁数</CardTitle>
            <UserX className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{stats?.totalBans || 0}</div>
            <p className="text-xs text-muted-foreground">历史总计</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">待审核</CardTitle>
            <Clock className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-primary">{stats?.pendingReviews || 0}</div>
            <p className="text-xs text-muted-foreground">等待批准</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">活跃封禁</CardTitle>
            <Users className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-destructive">{stats?.activeBans || 0}</div>
            <p className="text-xs text-muted-foreground">当前被封禁</p>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
