"use client"

import { useState, useEffect } from "react"
import { Badge } from "@/components/ui/badge"
import { Wifi, WifiOff } from "lucide-react"
import { unionBanAPI } from "@/lib/api"

export function ApiStatusIndicator() {
  const [isOnline, setIsOnline] = useState<boolean | null>(null)
  const [lastCheck, setLastCheck] = useState<Date | null>(null)

  const checkApiStatus = async () => {
    try {
      const status = await unionBanAPI.healthCheck()
      setIsOnline(status)
      setLastCheck(new Date())
    } catch {
      setIsOnline(false)
      setLastCheck(new Date())
    }
  }

  useEffect(() => {
    checkApiStatus()
    const interval = setInterval(checkApiStatus, 30000) // Check every 30 seconds
    return () => clearInterval(interval)
  }, [])

  if (isOnline === null) {
    return (
      <Badge variant="secondary" className="flex items-center gap-1">
        <Wifi className="h-3 w-3" />
        Checking...
      </Badge>
    )
  }

  return (
    <Badge variant={isOnline ? "default" : "destructive"} className="flex items-center gap-1">
      {isOnline ? <Wifi className="h-3 w-3" /> : <WifiOff className="h-3 w-3" />}
      {isOnline ? "API Online" : "API Offline"}
    </Badge>
  )
}
