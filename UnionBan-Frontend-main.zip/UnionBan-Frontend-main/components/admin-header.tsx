"use client"

import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { LogOut, User } from "lucide-react"
import { ApiStatusIndicator } from "@/components/api-status-indicator"
import { unionBanAPI } from "@/lib/api"

export function AdminHeader() {
  const router = useRouter()

  const handleLogout = () => {
    unionBanAPI.logout()
    router.push("/login")
  }

  return (
    <header className="bg-card border-b border-border px-6 py-4">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-4">
          <h2 className="text-2xl font-bold text-card-foreground">管理仪表板</h2>
          <ApiStatusIndicator />
        </div>

        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-sm text-muted-foreground">
            <User className="h-4 w-4" />
            <span>管理员</span>
          </div>
          <Button variant="outline" size="sm" onClick={handleLogout} className="flex items-center gap-2 bg-transparent">
            <LogOut className="h-4 w-4" />
            登出
          </Button>
        </div>
      </div>
    </header>
  )
}
