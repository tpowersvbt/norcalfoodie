"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription } from "@/components/ui/alert"
import { Badge } from "@/components/ui/badge"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { CheckCircle, AlertTriangle, RefreshCw, Clock } from "lucide-react"
import { unionBanAPI } from "@/lib/api"

interface PendingBan {
  id: string
  username: string
  reason: string
  server: string
  created_by: string
  expires_at: string | null
  is_permanent: boolean
  created_at: string
}

export function ReviewBansInterface() {
  const [pendingBans, setPendingBans] = useState<PendingBan[]>([])
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState("")
  const [reviewingId, setReviewingId] = useState<string | null>(null)

  const loadPendingBans = async () => {
    try {
      setLoading(true)
      setError("")

      console.log("[v0] 开始获取待审核封禁列表")
      const response = await unionBanAPI.getBansNoVerify()
      console.log("[v0] API响应:", response)

      if (response && response.data && response.data.bans) {
        const bans = Array.isArray(response.data.bans) ? response.data.bans : []
        console.log("[v0] 解析的封禁数据:", bans)
        setPendingBans(
          bans.map((ban: any) => ({
            id: ban.id?.toString() || Math.random().toString(),
            username: ban.username || "未知用户",
            reason: ban.reason || "无原因",
            server: ban.server || "未知服务器",
            created_by: ban.created_by || "未知管理员",
            expires_at: ban.expires_at,
            is_permanent: ban.is_permanent === "true" || ban.is_permanent === true,
            created_at: ban.created_at || new Date().toISOString(),
          })),
        )
      } else {
        // 如果API没有返回数据或返回空数据，显示空列表
        console.log("[v0] API返回空数据或无效响应")
        setPendingBans([])
      }
    } catch (err) {
      console.error("[v0] 获取待审核封禁失败:", err)
      setError(err instanceof Error ? err.message : "获取待审核封禁失败")
      // 出错时也设置为空列表
      setPendingBans([])
    } finally {
      setLoading(false)
    }
  }

  const handleReviewBan = async (banId: string) => {
    try {
      setReviewingId(banId)
      await unionBanAPI.reviewBan({ ban_id: banId })

      // Remove the reviewed ban from the list
      setPendingBans((prev) => prev.filter((ban) => ban.id !== banId))
    } catch (err) {
      setError(err instanceof Error ? err.message : "审核封禁失败")
    } finally {
      setReviewingId(null)
    }
  }

  const formatDate = (dateString: string) => {
    try {
      return new Date(dateString).toLocaleString()
    } catch {
      return dateString
    }
  }

  useEffect(() => {
    loadPendingBans()
  }, [])

  if (loading) {
    return (
      <div className="flex items-center justify-center h-64">
        <RefreshCw className="h-8 w-8 animate-spin text-primary" />
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div className="flex items-center gap-2">
          <Clock className="h-5 w-5 text-primary" />
          <span className="text-lg font-semibold">
            {pendingBans.length} 个待审核{pendingBans.length !== 1 ? "" : ""}
          </span>
        </div>
        <Button onClick={loadPendingBans} variant="outline" size="sm">
          <RefreshCw className="h-4 w-4 mr-2" />
          刷新
        </Button>
      </div>

      {error && (
        <Alert variant="destructive">
          <AlertTriangle className="h-4 w-4" />
          <AlertDescription>{error}</AlertDescription>
        </Alert>
      )}

      {pendingBans.length === 0 ? (
        <Card>
          <CardContent className="pt-6">
            <div className="text-center py-8">
              <CheckCircle className="h-12 w-12 text-chart-4 mx-auto mb-4" />
              <h3 className="text-lg font-semibold mb-2">暂无待审核项目</h3>
              <p className="text-muted-foreground">所有封禁请求都已审核完成。</p>
            </div>
          </CardContent>
        </Card>
      ) : (
        <Card>
          <CardHeader>
            <CardTitle>待审核封禁列表</CardTitle>
            <CardDescription>审核并批准管理员提交的封禁请求</CardDescription>
          </CardHeader>
          <CardContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>用户</TableHead>
                  <TableHead>服务器</TableHead>
                  <TableHead>原因</TableHead>
                  <TableHead>类型</TableHead>
                  <TableHead>创建者</TableHead>
                  <TableHead>提交时间</TableHead>
                  <TableHead>操作</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {pendingBans.map((ban) => (
                  <TableRow key={ban.id}>
                    <TableCell className="font-medium">{ban.username}</TableCell>
                    <TableCell>{ban.server}</TableCell>
                    <TableCell className="max-w-xs">
                      <div className="truncate" title={ban.reason}>
                        {ban.reason}
                      </div>
                    </TableCell>
                    <TableCell>
                      {ban.is_permanent ? (
                        <Badge variant="destructive">永久封禁</Badge>
                      ) : (
                        <Badge variant="secondary">
                          到期时间 {ban.expires_at ? formatDate(ban.expires_at) : "手动"}
                        </Badge>
                      )}
                    </TableCell>
                    <TableCell>{ban.created_by}</TableCell>
                    <TableCell className="text-sm text-muted-foreground">{formatDate(ban.created_at)}</TableCell>
                    <TableCell>
                      <div className="flex items-center gap-2">
                        <Button
                          size="sm"
                          onClick={() => handleReviewBan(ban.id)}
                          disabled={reviewingId === ban.id}
                          className="flex items-center gap-1"
                        >
                          {reviewingId === ban.id ? (
                            <RefreshCw className="h-3 w-3 animate-spin" />
                          ) : (
                            <CheckCircle className="h-3 w-3" />
                          )}
                          批准
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      )}
    </div>
  )
}
